#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#define _CRT_SECURE_NO_WARNINGS

void Color_det(int Maxell);
void timegetter(int timeworked[6][2], int day);
void theSplitter(char* str, int timeworked[6][2], int* day);
int timeCalc(int timeworked[6][2]);
void Title_Print();
void Menu_Print();
void Instruction_Print();
void LongLineDraw(int ingersoll);
//function.h

















